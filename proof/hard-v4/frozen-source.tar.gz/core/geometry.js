export function widthEvidence(element,{text=false}={}) {
  const document=element.ownerDocument
  const view=document.defaultView
  const outer=element.getBoundingClientRect()
  const lines=[]
  function clipping(node) {
    let left=0,right=view.innerWidth
    for(let parent=node;parent && parent!==document.body;parent=parent.parentElement) {
      if(view.getComputedStyle(parent).overflowX==='visible') continue
      const bounds=parent.getBoundingClientRect()
      left=Math.max(left,bounds.left+parent.clientLeft)
      right=Math.min(right,bounds.left+parent.clientLeft+parent.clientWidth)
    }
    return {left,right}
  }
  function add(rectangles,clip) {
    for(const rect of rectangles) if(rect.width>0) {
      lines.push({left:rect.left,right:rect.right,top:rect.top,bottom:rect.bottom,clipLeft:clip.left,clipRight:clip.right})
    }
  }
  if(text) {
    const walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT)
    const range=document.createRange()
    for(let node=walker.nextNode();node;node=walker.nextNode()) {
      const text=node.textContent
      if(!text.trim()) continue
      const clip=clipping(node.parentElement)
      range.selectNodeContents(node)
      const rectangles=[...range.getClientRects()]
      if(rectangles.every(rect=>rect.left>=clip.left-1 && rect.right<=clip.right+1)) {
        add(rectangles,clip)
      } else {
        for(const word of text.matchAll(/\S+/g)) {
          range.setStart(node,word.index)
          range.setEnd(node,word.index+word[0].length)
          add(range.getClientRects(),clip)
        }
      }
    }
  } else add([outer],clipping(element.parentElement))
  return {
    left:Math.min(...lines.map(rect=>rect.left)),right:Math.max(...lines.map(rect=>rect.right)),
    width:view.innerWidth,scrollX:view.scrollX,clientWidth:element.clientWidth,scrollWidth:element.scrollWidth,
    inView:lines.some(rect=>rect.bottom>0 && rect.top<view.innerHeight),
    fits:lines.length>0 && outer.width>0 && lines.every(rect=>rect.left>=rect.clipLeft-1 && rect.right<=rect.clipRight+1) &&
      (text || !element.clientWidth || element.scrollWidth<=element.clientWidth+1) && Math.abs(view.scrollX)<=1
  }
}

export function exactPassage(selector,quote) {
  const matches=[...document.querySelectorAll(selector)].filter(node=>
    node.getClientRects().length && node.textContent.replace(/\s+/g,' ').trim().includes(quote))
  return matches.length===1?matches[0]:null
}

export function observePassage(selector,quote,report) {
  let previous='',scheduled=false
  const sample=()=>{
    scheduled=false
    const target=exactPassage(selector,quote)
    if(!target) return
    const geometry=widthEvidence(target,{text:true})
    if(!geometry.inView) return
    const key=JSON.stringify([geometry.left,geometry.right,geometry.width,geometry.fits,geometry.scrollX])
    if(key===previous) return
    previous=key
    report('passage',target,{geometry})
  }
  const schedule=()=>{
    if(scheduled) return
    scheduled=true
    requestAnimationFrame(sample)
  }
  document.addEventListener('DOMContentLoaded',schedule,{once:true})
  window.addEventListener('load',schedule,{once:true})
  window.addEventListener('scroll',schedule,true)
  window.addEventListener('resize',schedule)
  schedule()
}

import test from 'node:test'
import assert from 'node:assert/strict'
import {judgeJourney,parseRun} from '../core/kane.mjs'
import {checkPatch,fix,repairLocally} from '../core/loop.mjs'
import {readJSON} from '../core/io.mjs'
import {match} from '../core/engine.js'
const original=(await readJSON('extension/demo.json'))[0]
const task=await readJSON('tasks/keyboard-only.json')
const result=(status,n)=>({status,runId:'test-'+n,video:'unit-'+n+'.mp4'})
test('only agreeing Kane run_end and exit code can provide a verdict',()=>{
 for(const [code,status,expected] of [[0,'passed','pass'],[1,'failed','fail'],[1,'passed','inconclusive'],[2,'failed','inconclusive']]){
  assert.equal(parseRun({code,stdout:JSON.stringify({type:'run_end',status,session_dir:'/tmp/unit'})}).status,expected)
 }
 assert.equal(parseRun({code:2,stdout:'not authenticated'}).status,'inconclusive')
 assert.equal(parseRun({code:1,stdout:JSON.stringify({type:'run_end',status:'failed',reason_code:'agent_error.child_failed'})}).status,'inconclusive')
 assert.equal(parseRun({code:1,stdout:JSON.stringify({type:'run_end',status:'failed',reason_code:'assertion_error.step_not_achievable',reason:'The run turn budget was exhausted.'})}).status,'inconclusive')
})
test('reject out-of-scope origins, unknown actions and unrestricted CSS',()=>{
 assert(match(original,task.url))
 assert(!match(original,task.url.replace('4317','4318')))
 for(const rule of [{action:'script',value:'anything'},{action:'injectCSS',value:{background:'url(https://example.org)'}}])assert(!match({...original,rules:[{selector:'body',...rule}]},task.url))
})
test('fix grants verified status only after failed baseline, passing control and recorded successful replay',async()=>{
 const sequence=['fail','pass','fail','pass']
 let publishes=0,drafts=0
 const actual=await fix(task,{base:'/tmp/unused',run:async()=>result(sequence.shift(),sequence.length),write:async()=>{drafts++;const proposal=structuredClone(original);if(drafts===1) proposal.rules.pop();return proposal},persist:async patch=>{publishes++;assert.equal(patch.evidence.kaneRunIds.length,3)}})
 assert.equal(actual.status,'verified');assert.equal(drafts,2);assert.equal(publishes,1)
 const failed=await fix(task,{base:'/tmp/unused',run:async()=>result('fail',0),write:()=>assert.fail(),persist:()=>assert.fail()})
 assert.equal(failed.status,'inconclusive')
})
test('recheck preserves verified on inconclusive, retires on native pass and invokes repair on patched fail',async()=>{
 for(const [seq,expected] of [[['inconclusive'],'verified'],[['pass'],'retired'],[['fail','fail'],'broken']]){
  const copy=structuredClone(original);copy.status='verified'
  let repaired=false
  await checkPatch(copy,{base:'/tmp/unused',run:async()=>result(seq.shift(),seq.length),persist:async()=>{},repair:async()=>{repaired=true}})
  assert.equal(copy.status,expected);assert.equal(repaired,expected==='broken')
 }
})
test('schema feedback consumes one shared attempt and reaches the next proposal',async()=>{
 const {mkdtemp,rm,readFile}=await import('node:fs/promises')
 const {tmpdir}=await import('node:os')
 const {join}=await import('node:path')
 const directory=await mkdtemp(join(tmpdir(),'curbcut-proposal-test-'))
 let proposals=0
 try {
  const statuses=['fail','pass','pass']
  const replay=await fix(task,{base:directory,run:async()=>result(statuses.shift(),statuses.length),
   write:async(_task,failure)=>{
    proposals++
    if(proposals===1) return {...original,rules:[]}
    assert.match(failure.validationError,/minItems/)
    return structuredClone(original)
   },persist:async()=>{}})
  assert.equal(replay.status,'verified')
  assert.equal(proposals,2)
  assert.equal(statuses.length,0)
  assert.match(await readFile(join(directory,'attempt-1/rejection.txt'),'utf8'),/minItems/)
 }finally{await rm(directory,{recursive:true,force:true})}
})

test('a v3 probe resolves a sealed checkpoint disagreement using witnessed width',async()=>{
 const {judgeProbe}=await import('../core/kane.mjs')
 const task={observedSelector:'#passage',probe:{action:'read'},outcomeChecks:[
  {selector:'#passage',kind:'contains',equals:'Exact quote'},{selector:'#passage',kind:'fits-width'}
 ]}
 const inspection={harness:{documentId:'current'}}
 const event={type:'passage',top:true,targetMatches:true,documentId:'current'}
 const grade=(fits,checks,kaneStatus)=>judgeProbe({task,persona:'low-vision',inspection,checks,kaneStatus,events:[{...event,geometry:{fits}}]})
 assert.equal(grade(true,[true,true],'fail').status,'pass')
 assert.equal(grade(false,[true,false],'pass').status,'fail')
 assert.equal(grade(true,[true,false],'pass').basis,'passage-layout-changed')
 assert.equal(grade(false,[false,false],'pass').basis,'passage-changed')
})

test('a named proxy and a real Tab landing are required for structured persona passes',async()=>{
 const {judgeProbe}=await import('../core/kane.mjs')
 const inspection={harness:{documentId:'current'},target:{visible:true,tabIndex:-1}}
 const task={requiredName:'Search catalog',probe:{action:'type',role:'textbox'}}
 const grade=(persona,events,checks=[true])=>judgeProbe({task,persona,inspection,checks,kaneStatus:'pass',events})
 const text={type:'reader-text',name:'',role:'textbox',targetMatches:true}
 assert.equal(grade('screen-reader-view',[text]).status,'fail')
 assert.equal(grade('screen-reader-view',[{...text,name:task.requiredName}]).status,'pass')
 const input={type:'text',targetMatches:true,documentId:'current'}
 const tabFocus={...input,type:'tab-focus'}
 assert.equal(grade('keyboard-only',[input]).status,'inconclusive')
 assert.equal(grade('keyboard-only',[input,tabFocus]).status,'inconclusive')
 assert.equal(grade('keyboard-only',[tabFocus,input]).status,'pass')
 const tabs=[{type:'tab',documentId:'current'},{type:'tab',documentId:'current'}]
 assert.equal(grade('keyboard-only',tabs,[false]).basis,'target-skipped-by-tab')
})

test('the local oracle screens failing patches before Kane and tolerates an inconclusive Kane baseline',async()=>{
 const probed={...task,observedSelector:'div.add-to-cart',probe:{action:'click'},outcomeChecks:[{kind:'visible',selector:'body'}]}
 const kane=['inconclusive','pass','pass']
 const calls=[]
 let replays=0
 const outcome=await fix(probed,{base:'/tmp/unused-oracle',
  check:async(_task,patch)=>patch?(++replays===1?{status:'fail',reason:'still skipped'}:{status:'pass'}):{status:'confirmed',persona:{snapshot:null}},
  run:async(_task,persona,patch)=>{calls.push(persona+(patch?'+patch':''));return result(kane.shift(),kane.length)},
  write:async(_task,failure)=>{const proposal=structuredClone(original);if(replays===1) assert.match(failure.reason,/still skipped/);return replays===0?{...proposal,rules:proposal.rules.slice(0,1)}:proposal},
  persist:async patch=>assert.equal(patch.evidence.kaneVerdicts.before,'inconclusive')})
 assert.equal(outcome.status,'verified')
 assert.deepEqual(calls,['keyboard-only','control','keyboard-only+patch'])
 const none=await fix(probed,{base:'/tmp/unused-oracle',check:async()=>({status:'no barrier'}),run:()=>assert.fail(),write:()=>assert.fail()})
 assert.equal(none.status,'already-accessible')
})

test('Kane journeys require ordered actions and a witnessed intermediate outcome',()=>{
 const task={barrierClass:4,journey:[
  {selector:'#open',action:'activate',checks:[{kind:'visible',selector:'#dialog'}]},
  {selector:'#dialog',action:'key',key:'Escape',pointer:{action:'click',selector:'#close'}}
 ]}
 const activation={type:'activate',stepTargets:['#open'],top:true}
 const checkpoint={type:'journey-checkpoint',index:0,top:true}
 const escape={type:'key',key:'Escape',stepTargets:['#dialog','#close'],top:true}
 const inputs={task,persona:'keyboard-only',checks:[true],kaneStatus:'pass'}
 assert.equal(judgeJourney({...inputs,events:[activation,checkpoint,escape]}).status,'pass')
 assert.equal(judgeJourney({...inputs,events:[activation,escape]}).status,'inconclusive')
 assert.equal(judgeJourney({...inputs,events:[escape,activation,checkpoint]}).status,'inconclusive')
 assert.equal(judgeJourney({...inputs,events:[activation],kaneStatus:'fail'}).status,'fail')
 const pointerOpen={type:'pointer-click',stepTargets:['#open'],top:true}
 const pointerClose={type:'pointer-click',stepTargets:['#close'],top:true}
 assert.equal(judgeJourney({...inputs,persona:'control',events:[pointerOpen,checkpoint,pointerClose]}).status,'pass')
})

test('the Playwright loop keeps a successful patch as a candidate and preserves the pointer result',async()=>{
 const {mkdtemp,rm}=await import('node:fs/promises')
 const {tmpdir}=await import('node:os')
 const {join}=await import('node:path')
 const base=await mkdtemp(join(tmpdir(),'curbcut-local-test-'))
 try {
  const outcomes=['pass','fail','pass','pass']
  const replay=await repairLocally(task,{base,write:async()=>structuredClone(original),
   replay:async()=>({status:outcomes.shift(),runner:'playwright'})})
  assert.equal(replay.runner,'playwright')
  assert.equal(replay.status,'locally-fixed')
  assert.equal(replay.patch.status,'candidate')
  assert.equal(replay.phases.at(-1).name,'attempt-1/control-with-patch')
  assert.equal(outcomes.length,0)
 } finally {await rm(base,{recursive:true,force:true})}
})

test('a registered patch requires three sealed Kane results before publication',async()=>{
 const {mkdtemp,rm}=await import('node:fs/promises')
 const {tmpdir}=await import('node:os')
 const {join}=await import('node:path')
 const base=await mkdtemp(join(tmpdir(),'curbcut-kane-test-'))
 try {
  const candidate={...structuredClone(original),id:task.id,url:task.url,task:task.task}
  const stages=['fail','pass','inconclusive','pass']
  const verified=[]
  const run=async()=>({...result(stages.shift(),stages.length),runner:'kane',evidenceValid:true})
  const options={base,registeredCandidate:candidate,provenance:{priorAgentProposal:'local/candidate.json',sourceLocalRun:'local/before.json'},
   run,persist:async patch=>verified.push(patch)}
  const actual=await fix(task,options)
  assert.equal(actual.status,'verified')
  assert.equal(verified.length,1)
  assert.equal(stages.length,0)
  stages.push('inconclusive','pass','pass')
  assert.equal((await fix(task,options)).status,'inconclusive')
  assert.equal(verified.length,1)
 } finally {await rm(base,{recursive:true,force:true})}
})

test('extension feed validation accepts each declarative widget action',async()=>{
 const {runInNewContext}=await import('node:vm')
 const {readFile}=await import('node:fs/promises')
 const {ROOT}=await import('../core/io.mjs')
 const scope={}
 for(const file of ['constants','validate']) runInNewContext(await readFile(ROOT+'extension/lib/'+file+'.js','utf8'),scope)
 const journeys=await readJSON('fixtures/shop/journeys.json')
 for(const journey of journeys) {
  const patch={...structuredClone(original),rules:journey.rules}
  assert.equal(scope.CurbCutExt.validatePatch(patch).ok,true,journey.id)
  assert.equal(match(scope.CurbCutExt.toEnginePatch(patch),task.url),true,journey.id)
 }
 assert.equal(scope.CurbCutExt.validatePatch({...original,rules:[{action:'listboxBehavior',trigger:'button'}]}).ok,false)
})

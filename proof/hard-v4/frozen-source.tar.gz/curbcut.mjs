#!/usr/bin/env node
import {readJSON} from './core/io.mjs'
import {fix,recheck,withLock} from './core/loop.mjs'
import {requireKane} from './core/kane.mjs'
import {serve} from './core/server.mjs'
const [action,file]=process.argv.slice(2)
try {
  if(action==='serve') {await serve();console.log('Curb Cut · http://127.0.0.1:4317/site/')}
  else if(action==='fix' && file) {
    const task=await readJSON(file)
    await requireKane()
    const result=await withLock(()=>fix(task))
    console.log(JSON.stringify(result,null,2))
    if(!['already-accessible','verified'].includes(result.status)) process.exitCode=1
  } else if(action==='recheck') console.log(JSON.stringify(await withLock(()=>recheck(file)),null,2))
  else console.log('curbcut serve | curbcut fix <task.json> | curbcut recheck [patch-id|--public]')
} catch(error) {console.error(error.message);process.exitCode=2}

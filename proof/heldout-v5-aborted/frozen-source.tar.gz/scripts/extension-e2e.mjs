import {chromium} from 'playwright'
import {createHash} from 'node:crypto'
import {mkdtemp,readFile,rm} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import path from 'node:path'
import {setTimeout as delay} from 'node:timers/promises'
import {BlockedPage,pageBlock} from '../core/access.mjs'
import {guardRequests} from '../core/chrome.mjs'
import {ROOT,instant,saveJSON} from '../core/io.mjs'
import {journeyLane} from '../core/probe.mjs'
import {normalizeTask,siteKey,taskDestination} from '../core/task.mjs'

const extension=path.join(ROOT,'extension')
const runtime=await readFile(path.join(extension,'runtime.js'),'utf8')
const bundleBytes=await readFile(path.join(extension,'bundled.json'))
const bundled=JSON.parse(bundleBytes)
const output=path.join(ROOT,'proof/reliability/extension-e2e.json')
const only=process.argv[2]
const patches=only?bundled.filter(patch=>patch.id===only):bundled
if(!patches.length) throw new Error('No bundled patch matches the requested audit.')

const ask=(popup,message)=>popup.evaluate(message=>chrome.runtime.sendMessage(message),message)

async function queryActive(popup,url) {
  return popup.evaluate(async url=>{
    const tabs=await chrome.tabs.query({})
    const matches=tabs.filter(tab=>tab.url===url)
    if(matches.length!==1) return {ok:false,reason:'task-tab-is-not-unique'}
    return chrome.runtime.sendMessage({type:'QUERY_ACTIVE',capturedTabId:matches[0].id,includeMatches:true})
  },url)
}

async function audit(patch) {
  const url=patch.url??patch.match.replace(/\*$/,'')
  const row={id:patch.id,url,persona:patch.persona,journey:Boolean(patch.journey)}
  const task=await normalizeTask({...patch,url})
  const profile=await mkdtemp(path.join(tmpdir(),'curbcut-extension-'))
  let context
  try {
    context=await chromium.launchPersistentContext(profile,{channel:'chromium',headless:true,acceptDownloads:false,
      viewport:{width:task.persona==='low-vision'?320:1280,height:800},
      args:['--disable-extensions-except='+extension,'--load-extension='+extension,'--disable-background-networking']})
    await guardRequests(context,task,{extension:true})
    const worker=context.serviceWorkers().find(worker=>worker.url().startsWith('chrome-extension:'))??
      await context.waitForEvent('serviceworker',{predicate:worker=>worker.url().startsWith('chrome-extension:'),timeout:8000})
    if(task.journey) {
      const settings=JSON.stringify({persona:task.persona,site:siteKey(new URL(task.url))})
      await context.addInitScript({content:runtime+'\n;('+function({persona,site}) {
        if(location.protocol==='https:' && (location.hostname===site || location.hostname.endsWith('.'+site))) CurbCut.enforce(persona)
      }.toString()+')('+settings+')'})
    }
    const popup=await context.newPage()
    await popup.goto(new URL('popup.html',worker.url()).href)
    const feed=await ask(popup,{type:'REFRESH_FEEDS'})
    if(!feed.ok || !feed.state.patches.some(candidate=>candidate.id===patch.id)) throw new Error('The extension did not load the bundled patch.')
    const responses=new Map()
    context.on('response',response=>{
      const request=response.request()
      try {
        const frame=request.frame()
        if(request.isNavigationRequest() && frame===frame.page().mainFrame()) responses.set(frame.page(),response)
      } catch {}
    })

    async function lane(enabled) {
      const toggle=await ask(popup,{type:'SET_ENABLED',enabled})
      if(!toggle.ok || toggle.state.enabled!==enabled) throw new Error('The extension switch did not change state.')
      const page=await context.newPage()
      try {
        let response
        try {response=await page.goto(task.url,{waitUntil:'domcontentloaded',timeout:25000})}
        catch(error) {throw new BlockedPage(error.message.split('\n')[0])}
        const blocked=await pageBlock(page,response)
        if(blocked) throw new BlockedPage(blocked)
        if(!taskDestination(task,new URL(page.url()))) throw new BlockedPage('Public navigation left the registered site.')
        await page.bringToFront()
        const selectorMatches=new Map(),matchedRules=new Set()
        let active=false,queryWorked=false
        async function observe(target) {
          const query=await queryActive(popup,target.url())
          const current=query.active?.find(candidate=>candidate.id===patch.id)
          queryWorked ||= query.ok===true
          active ||= Boolean(current)
          for(const index of current?.matchedRules??[]) matchedRules.add(index)
          for(const match of current?.selectorMatches??[]) {
            const key=match.index+'.'+match.field
            const previous=selectorMatches.get(key)
            if(!previous || (!match.issue && previous.issue) || match.count>previous.count) selectorMatches.set(key,match)
          }
        }
        const selectorsConfirmed=()=>active && matchedRules.size===patch.rules.length && selectorMatches.size>0 && [...selectorMatches.values()].every(match=>!match.issue)
        const deadline=Date.now()+(task.journey?4000:8000)
        do {
          await observe(page)
          if(queryWorked && ((!enabled && !active) || (enabled && (selectorsConfirmed() || task.journey && active)))) break
          await delay(200)
        } while(Date.now()<deadline)
        if(!queryWorked) throw new Error('The popup could not query the live extension page.')
        let journey
        if(task.journey && (enabled?active:!active)) {
          const browser={page,context,responses,async activePage(expected){
            const pages=context.pages().filter(candidate=>taskDestination(task,new URL(candidate.url())))
            return pages.find(candidate=>candidate.url()===expected)??pages.at(-1)
          }}
          journey=await journeyLane(browser,task,task.persona,{onDOM:enabled?observe:undefined})
        }
        return {enabled,active,landed:page.url(),httpStatus:response?.status(),matchedRules:[...matchedRules].sort((a,b)=>a-b),
          selectorsConfirmed:selectorsConfirmed(),selectorMatches:[...selectorMatches.values()],journey}
      } finally {
        await Promise.all(context.pages().filter(candidate=>candidate!==popup).map(candidate=>candidate.close()))
      }
    }

    if(task.journey) row.off=await lane(false)
    row.on=await lane(true)
    if(!row.on.active) return {...row,status:'inactive',reason:'The popup did not report the bundled patch on its task page.'}
    if(!row.on.selectorsConfirmed) return {...row,status:'selector-miss',reason:'One or more rules or selector fields did not match in the installed extension.'}
    if(row.off?.active) return {...row,status:'inconclusive',reason:'The popup reported the patch while the extension switch was off.'}
    if(row.off?.journey?.status==='pass') return {...row,status:'already-accessible',reason:'The registered journey passed with the extension switched off.'}
    if(row.on.journey?.status==='fail') return {...row,status:'journey-fail',reason:row.on.journey.reason}
    if(task.journey && (row.off?.journey?.status!=='fail' || row.on.journey?.status!=='pass')) {
      return {...row,status:'inconclusive',reason:'The measured journey needs a failing off lane and a passing on lane.'}
    }
    return {...row,status:'pass'}
  } catch(error) {
    return {...row,status:error instanceof BlockedPage?'blocked':'inconclusive',reason:error.message.split('\n')[0]}
  } finally {
    await context?.close()
    await rm(profile,{recursive:true,force:true})
  }
}

const results=[]
for(const patch of patches) {
  let row
  try {row=await audit(patch)}
  catch(error) {row={id:patch.id,url:patch.url,status:'inconclusive',reason:error.message.split('\n')[0]}}
  results.push(row)
  console.error(results.length+'/'+patches.length,patch.id,row.status,row.reason??'')
  if(results.length<patches.length) await delay(900)
}
const counts=Object.fromEntries(Object.entries(Object.groupBy(results,row=>row.status)).map(([status,rows])=>[status,rows.length]))
const journeys=results.filter(row=>row.journey)
const summary={runner:'playwright-extension',checkedAt:instant(),bundleSha256:createHash('sha256').update(bundleBytes).digest('hex'),
  total:results.length,passed:counts.pass??0,counts,journeys:{total:journeys.length,passed:journeys.filter(row=>row.status==='pass').length},results}
if(only) console.log(JSON.stringify(summary,null,2))
else {
  await saveJSON(output,summary)
  console.log(summary.passed+'/'+summary.total+' bundled fixes passed the extension audit.')
}
